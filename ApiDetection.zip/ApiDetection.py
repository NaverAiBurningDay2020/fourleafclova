def ApiDetection(base_dir, file_name):
    import requests
    from decouple import config
    from time import sleep

    # 모듈화 : 일단 필요할 때마다 불러다 쓸 수 있게 하자!
    # url = 'https://openapi.naver.com'
    client_id = 'kc90u3at6n' #"YOUR_CLIENT_ID"
    client_secret = 'FKR5YUqPobmRpmMscbXS5yfQ17bL33cg008xxyE3' #"YOUR_CLIENT_SECRET"
    # url = 'https://naveropenapi.apigw.ntruss.com/vision-pose/v1/estimate'
    url = 'https://naveropenapi.apigw.ntruss.com/vision-obj/v1/detect'
    dir_base = './image'

    headers = { 
        'X-NCP-APIGW-API-KEY-ID': client_id, #config('CLIENT_ID'),
        'X-NCP-APIGW-API-KEY': client_secret #config('CLIENT_SECRET'),
        # 'Content-Type': "multipart/form-data",
        # 'Content-Length': 96703
    }
    print('Object Detection: ')
    try:
        if file_name[-4:-1] != '.png' or file_name[-4:-1] != '.jpg':
            print(ErrorGenerate)
        # file_name = filename+'.png'
    except:
        print('파일형식 오류입니다! 파일 확장자명은 jpg or png이어야 합니다.')

    try:
        file_dir = base_dir+file_name
        files = {'image': open(file_dir, 'rb')}

        file_dir=base_dir+file_name  #+'/baby'+ str(i)+'.jpg'
        # file_neme = 'baby6.jpg'
        # base_dir = './image/'
        files = {'image': open(file_dir, 'rb')}

        response = requests.post(url,  files=files, headers=headers)
        sleep(100)
        rescode = response.status_code
        if(rescode==200):
            print (response.text)
        else:
            print("Detection-Res Error Code:" + rescode)
    except:
            print('이미지는 2MB이하여야 합니다! 데이터 용량을 체크해주세요 file_dir :{}'.fomrat(file_dir))


        # except:
        #     print("Estimate Exception1 + Error2 (사진 파일의 jpg, png 확장자 모두 틀림 or 용량이 2MB넘는지 체크! 문제) )
        
            